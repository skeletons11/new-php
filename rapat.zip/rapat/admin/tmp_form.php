<?php
include 'header.php';
include 'navbar.php';
include 'sidebar.php';
include 'tmp_form_content.php';
include 'footer.php';
?>